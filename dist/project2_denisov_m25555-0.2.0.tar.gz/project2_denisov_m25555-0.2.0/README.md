# Primitive DB Project

Учебный проект простой базы данных на Python.

## Установка

```bash
make install
