# Project2 Denisov M25-555

Проект базы данных с интерфейсом командной строки.

## Установка

```bash
make install
make package-install
