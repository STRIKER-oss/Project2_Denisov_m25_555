#!/usr/bin/env python3
"""Основной модуль primitive_db."""


def main():
    """Главная функция primitive_db."""
    print("DB project is running!")


if __name__ == "__main__":
    main()